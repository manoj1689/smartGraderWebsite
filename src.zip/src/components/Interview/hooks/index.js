// Exporting all hooks from one file for easier imports
export { useQuestions } from './useQuestions';
export { useSubmitAnswer } from './useSubmitAnswer';
